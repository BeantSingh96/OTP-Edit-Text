package com.example.demootp;

public interface OnOtpCompletionListener {
    void onOtpCompleted(String otp);
}
